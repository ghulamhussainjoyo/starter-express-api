export enum PermissionFlag {
    USER = 1,
    MODERATOR = 2,
    ADMIN = 3,
}