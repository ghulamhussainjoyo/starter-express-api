type ReqDictionary = {}
type ReqBody = { foo1?: string }
type ReqQuery = { heading?: string, category?: string, region?: string }
type ResBody = { foo3?: string }



export { ReqBody, ReqDictionary, ReqQuery, ResBody }