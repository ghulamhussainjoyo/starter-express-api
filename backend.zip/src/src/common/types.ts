export type Jwt = {
    refreshKey: string;
    userId: string;
    permissionFlags: string;
};