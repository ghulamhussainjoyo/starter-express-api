export const dbConfig = {
    host: '82.180.175.51',
    user: 'u312645649_crm',
    password: 'Rouelite123',
    database: 'u312645649_crm'
    //  host: 'localhost',
    // user: 'students_rouelite',
    // password: 'Z5ZF^}QC8ulW',
    // database: 'students_rouelite_crm'
}



// user // rouelite_crm
// pass // RoueliteTechno@11#