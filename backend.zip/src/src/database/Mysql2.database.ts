import mysql from 'mysql2/promise';
import { dbConfig } from '../common/config';

class Database {
    pool: mysql.Pool;

    constructor() {
        this.pool = mysql.createPool(dbConfig);

        this.pool.on('acquire', (connection) => {
            console.log('Connection acquired');
        });


    }

    public async query(sqlQuery: string): Promise<any> {
        try {
            const connection = await this.pool.getConnection();
            const [results,] = await connection.execute(sqlQuery);
            connection.release();
            return results;
        } catch (error) {
            console.error('Error:', error);
            throw error;
        }
    }

    public async queryWithValue(sqlQuery: string, value: any): Promise<any> {
        try {
            const connection = await this.pool.getConnection();
            const [results,] = await connection.execute(mysql.format(sqlQuery, value));
            connection.release();
            return results;
        } catch (error) {
            console.error('Error:', error);
            throw error;
        }
    }

    private async reconnect(): Promise<void> {
        console.log('Reconnecting to database...');
        try {
            const newPool = mysql.createPool({
                host: 'localhost',
                user: 'root',
                password: 'mypassword',
                database: 'mydatabase',
                connectionLimit: 10
            });

            // Test the connection
            await newPool.query('SELECT 1');

            // Update the pool reference
            this.pool = newPool;

            console.log('Database connection re-established');
        } catch (error) {
            console.error('Error reconnecting to database:', error);
            setTimeout(() => this.reconnect(), 2000);
        }
    }
}
export default new Database()