export interface createClosingDto {
    crmID?: string,
    sales_person?: string,
    lead_person?: string,
    total_amount?: string,
    quote_serial?: string,
    system_details?: string,
    cheque_number?: string,
    advance_price?: string,
}