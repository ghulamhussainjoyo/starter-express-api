export interface quoteDto {
    crmID?: string;
    system_type?: string
    structure_type?: string
    solar_requirements?: number
    total_price?: number
    advance_price?: number
    other_quote?: string
}