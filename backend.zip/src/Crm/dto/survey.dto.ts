export interface createSurveyDto {
    crmID?: string,
    surveyor_name?: string,
    total_amperes?: string,
    meter_type?: string,
    gps_coordinates?: string,
    roof_type?: string,
    system_type?: string,
    solar_requirements?: string,
    other_survey?: string,
}