export interface createMeetingDto {
    poc_name?: string,
    panel_names?: string,
    poc_contact?: string,
    venue_address?: string,
}