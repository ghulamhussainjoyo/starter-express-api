export interface createLeadDto {
    client_name?: string,
    client_contact?: string,
    city?: string,
    monthly_consumption?: string,
    solar_requirements?: string,
    monthly_bill_amount?: string,
}